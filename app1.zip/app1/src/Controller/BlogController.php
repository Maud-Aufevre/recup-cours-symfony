<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class BlogController extends AbstractController
{
    /**
     * @Route("/blog", name="blog")
     */
    public function index()
    {
        return $this->render('blog/index.html.twig', [
            'controller_name' => 'BlogController',
        ]);
    }

     /**
     * @Route("/home", name="blog_home")
     */
    public function home()
    {
        return $this->render('blog/home.html.twig');
    }

     /**
     * @Route("/about_b", name="blog_about")
     */
    public function presentation()
    {
        return $this->render('blog/about.html.twig');
    }

     /**
     * @Route("/contact_b", name="blog_contact")
     */
    public function contact()
    {
        return $this->render('blog/contact.html.twig');
    }
}
