<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class ControllerBlog extends AbstractController {
    /**
     * @Route("/apropos", name="app_apropos")
     */
    public function apropos(){
        $title = "à propos";
        $txt = "Nunc condimentum dapibus sem, vitae pharetra nibh hendrerit sodales. Quisque vestibulum quis elit vel eleifend. Morbi et sagittis nibh, a fermentum lacus. Praesent at tempor nisi. In quis augue pharetra, gravida augue ut, aliquet leo. Etiam ac quam et tortor laoreet maximus a vitae risus. Nunc sed dui in nisi finibus ornare. Nullam ornare nunc turpis, ut hendrerit neque tempus vel. Aenean dignissim, magna eget finibus scelerisque, ex ante sagittis sapien, a gravida leo enim ut nulla. Suspendisse ullamcorper venenatis cursus. Donec lorem quam, laoreet id metus consectetur, luctus sodales sapien. Nam tincidunt, dui vel pretium hendrerit, lectus diam rhoncus ligula, fringilla cursus neque ligula id dolor. Sed in tempus elit. Mauris blandit condimentum orci, sed commodo felis imperdiet at. Fusce sed quam justo.";
        $img = "<img src='{{ asset('images/symfony.png') }}' alt=''>";
        // return new Response('A propos du Covid, nous sommes inquiets');
        return $this->render("default/apropos.html.twig", ['titre'=>$title, 'txt'=>$txt, 'img'=>$img]);
    }


}

?>
