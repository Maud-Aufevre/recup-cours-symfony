<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\BrowserKit\Response as BrowserKitResponse;

class WelcomeController extends AbstractController{
    public function welcome(){
        return new Response('
        <h1>Bienvenue</h1>
        Hello world
        <p>Nous sommes heureux de vous retrouver</p>
        ');
    }

    /**
     * @Route("/about", name="app_about")
     */
    public function about(){
        $title = "à propos";
        $matieres = ['html', 'css', 'js'];
        $age = 16;
        // return new Response('A propos du Covid, nous sommes inquiets');
        return $this->render("default/about.html.twig", ['titre'=>$title, 'matieres'=>$matieres, 'age'=>$age]);
    }

    /**
     * @Route("/contact", name="app_contact")
     */
    public function contact(){
        return $this->render('default/contact.html.twig');
    }

    /**
     * @Route("/product/{id}", name="app_product")
     */
    public function afficheProduit($id){
        return $this->render('default/produit.html.twig',['id'=>$id]);
    }
}

?>